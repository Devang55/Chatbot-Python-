intent_responses = {
    "cancel_order": [
        "Sure! I can help you cancel your order.",
        "I can assist you in canceling your order. Let me know the details.",
        "Let's get that order canceled for you."
    ],
    "change_order": [
        "Sure, I can help you change your order.",
        "I can assist with changing your order. What would you like to modify?",
        "Let's make the necessary changes to your order."
    ],
    "change_shipping_address": [
        "Let me help you update the shipping address.",
        "I can help with updating the shipping address.",
        "Sure! Let's update your shipping address."
    ],
    "check_cancellation_fee": [
        "I can look up the cancellation fee for you.",
        "Let me check the cancellation fee associated with this order.",
        "I'll help you with the cancellation fee details."
    ],
    "check_invoice": [
        "I can help you access your invoice.",
        "Let me retrieve your invoice for you.",
        "Sure, let's find your invoice information."
    ],
    "check_payment_methods": [
        "We offer several payment methods. Let me list them for you.",
        "I can assist you with the available payment options.",
        "Let me show you the payment methods we accept."
    ],
    "check_refund_policy": [
        "I’ll help you with our refund policy.",
        "Let me explain our refund policy.",
        "I can provide details on our refund policy."
    ],
    "complaint": [
        "I'm here to listen to your complaint.",
        "Please tell me more about your issue so I can help.",
        "I'm sorry to hear that. Let me know how I can assist."
    ],
    "contact_customer_service": [
        "I can connect you with our customer service team.",
        "Let me help you reach customer service.",
        "I'll direct you to customer support."
    ],
    "contact_human_agent": [
        "Connecting you to a human agent now.",
        "I’ll transfer you to an agent for further assistance.",
        "I'll get a human agent to help you."
    ],
    "create_account": [
        "I can help you create an account.",
        "Let's get you set up with a new account.",
        "I'm here to assist with your account setup."
    ],
    "delete_account": [
        "Are you sure you want to delete your account?",
        "I can help you delete your account. Let me confirm the details.",
        "Deleting your account will remove all your data. Shall I proceed?"
    ],
    "delivery_options": [
        "We offer various delivery options. Let me list them for you.",
        "I can help you explore our delivery choices.",
        "Let’s take a look at the delivery options available."
    ],
    "delivery_period": [
        "I’ll check the estimated delivery period for you.",
        "Let me provide the expected delivery timeline.",
        "I can tell you when your order is expected to arrive."
    ],
    "edit_account": [
        "I can help you edit your account details.",
        "Let’s make the necessary updates to your account.",
        "I’ll guide you through updating your account information."
    ],
    "get_invoice": [
        "Let me retrieve your invoice for you.",
        "I'll help you access your invoice.",
        "Here's how you can get your invoice."
    ],
    "get_refund": [
        "I can assist you with the refund process.",
        "Let me guide you through getting a refund.",
        "I’ll help you start the refund request."
    ],
    "newsletter_subscription": [
        "I can help you subscribe to our newsletter.",
        "Would you like to sign up for our latest updates?",
        "I'll add you to our newsletter list."
    ],
    "payment_issue": [
        "I'm here to help with any payment issues you're experiencing.",
        "Let me assist you with your payment problem.",
        "I'm here to resolve your payment issue."
    ],
    "place_order": [
        "I can help you place an order.",
        "Let me guide you through the ordering process.",
        "I'm here to assist with placing your order."
    ],
    "recover_password": [
        "I can help you recover your password.",
        "Let me assist with resetting your password.",
        "I’ll guide you through the password recovery process."
    ],
    "registration_problems": [
        "I can assist with any issues during registration.",
        "Let's resolve your registration problem.",
        "I'm here to help with your registration issue."
    ],
    "review": [
        "I would love to hear your feedback.",
        "Please leave a review about your experience.",
        "Your feedback is important to us. Let us know what you think!"
    ],
    "set_up_shipping_address": [
        "I can assist with setting up your shipping address.",
        "Let’s set up your shipping details.",
        "I’m here to help you add a new shipping address."
    ],
    "switch_account": [
        "I’ll help you switch to a different account.",
        "Let's switch to your other account.",
        "I can guide you through switching accounts."
    ],
    "track_order": [
        "Let me check the status of your order.",
        "I’ll track your order for you.",
        "I can provide the latest updates on your order."
    ],
    "track_refund": [
        "I can help you track your refund status.",
        "Let me check the status of your refund.",
        "I'll provide the latest information on your refund."
    ]
}

basic_intent_responses = {
    "hi": [
        "Hello! How can I help you today?",
        "Hi there! What can I assist you with?",
        "Hey! How may I assist you?"
    ],
    "hello": [
        "Hello! How can I help you today?",
        "Hi there! What can I assist you with?",
        "Hey! How may I assist you?"
    ],
    "hey": [
        "Hello! How can I help you today?",
        "Hi there! What can I assist you with?",
        "Hey! How may I assist you?"
    ],
    "good morning": [
        "Good morning! How can I assist you today?",
    ],
    "good afternoon": [
        "Good afternoon! How may I help you?"
    ],
    "good evening": [
        "Good evening! How can I be of service?"
    ],
    "bye": [
        "Goodbye! Feel free to reach out anytime.",
        "Bye! Have a great day!",
        "Take care! Let me know if you need further help."
    ],
    "how are you": [
        "I'm just a bot, but I'm here to help you!",
        "I'm doing well! How about you?",
        "I'm here and ready to assist you!"
    ],
    "what can you do": [
        "I can assist with orders, account management, and much more! How can I help?",
        "I can help you with orders, tracking, refunds, and other customer support queries!"
    ],
    "who are you": [
        "I'm your virtual assistant, here to help you with any questions or tasks."
    ],
    "yes": [
        "Great! Let's move forward.",
        "Perfect! Moving ahead.",
        "Awesome! I'll take that as a yes."
    ],
    "no": [
        "No problem, let me know what you need.",
        "Alright! Let me know if you change your mind."
    ],
    "maybe": [
        "No worries! Take your time and let me know when you're ready."
    ],
    "thanks": [
        "You're welcome!",
        "Happy to help! Anything else I can assist with?",
        "You're welcome! Let me know if there's anything else."
    ],
    "thank you": [
        "You're welcome!",
        "Happy to help! Anything else I can assist with?",
        "You're welcome! Let me know if there's anything else."
    ],
    "i dont know": [
        "That's okay! I'm here to help you figure things out."
    ],
    "i need help": [
        "Sure! What would you like help with?"
    ],
    "im confused": [
        "Let me clarify that for you! Can you tell me a bit more about what's confusing?"
    ],
    "tell me a joke": [
        "Why don't scientists trust atoms? Because they make up everything!",
        "Why did the scarecrow win an award? Because he was outstanding in his field!"
    ],
    "how am i doing": [
        "You're doing great! Is there anything else I can assist you with?"
    ],
    "am i talking to right person": [
        "You're talking to me, your assistant. Let me know what you need!"
    ],
    "are you a bot?": [
        "Yes, I am a bot designed to help you with customer support."
    ],
    "are you human?": [
        "Nope, I'm a bot! But I'm here to assist you just like a human would."
    ]
}
