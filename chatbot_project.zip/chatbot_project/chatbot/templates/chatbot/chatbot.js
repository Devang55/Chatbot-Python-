document.getElementById('send-button').addEventListener('click', function() {
    let userInput = document.getElementById('user_input').value;

    let chatBox = document.getElementById('chat-box');
    let userMessage = document.createElement('p');
    userMessage.textContent = "You said: " + userInput;
    userMessage.style.color = "green";
    chatBox.appendChild(userMessage);

    fetch('/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': document.querySelector('[name=csrfmiddlewaretoken]').value
        },
        body: new URLSearchParams({'message': userInput})
    })
    .then(response => response.json())
    .then(data => {
        let botReply = document.createElement('p');
        botReply.textContent = data.message;
        botReply.style.color = "blue";
        chatBox.appendChild(botReply);
    })
    .catch(error => console.error('Error:', error));

    document.getElementById('user_input').value = '';
});
