import os
import pickle
import random
from django.http import JsonResponse
from django.shortcuts import render
from .intent_responses import intent_responses, basic_intent_responses

# Load the chatbot model and vectorizer
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'chatbot_model.pkl')
VECTORIZER_PATH = os.path.join(os.path.dirname(__file__), 'tfidf_vectorizer.pkl')

try:
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
    with open(VECTORIZER_PATH, 'rb') as f:
        vectorizer = pickle.load(f)
    print("Model and vectorizer loaded successfully!")
except Exception as e:
    print(f"Error loading model or vectorizer: {e}")

# List of intent labels
intent_labels = [
    'cancel_order', 'change_order', 'change_shipping_address', 'check_cancellation_fee', 
    'check_invoice', 'check_payment_methods', 'check_refund_policy', 'complaint', 
    'contact_customer_service', 'contact_human_agent', 'create_account', 'delete_account', 
    'delivery_options', 'delivery_period', 'edit_account', 'get_invoice', 'get_refund', 
    'newsletter_subscription', 'payment_issue', 'place_order', 'recover_password', 
    'registration_problems', 'review', 'set_up_shipping_address', 'switch_account', 
    'track_order', 'track_refund'
]

def index(request):
    return render(request, 'chatbot/index.html')

# Process the chatbot response
def get_response(request):
    if request.method == 'POST':
        user_message = request.POST.get('message').lower()

        if not user_message:
            return JsonResponse({'message': "Please say something."})

        try:
            if user_message in basic_intent_responses:
                response = random.choice(basic_intent_responses[user_message])
            else:
                user_message_vector = vectorizer.transform([user_message])

                predicted_intent_index = model.predict(user_message_vector)[0]
                print(f"Predicted intent (index): {predicted_intent_index}")

                if predicted_intent_index < len(intent_labels):
                    predicted_intent_label = intent_labels[predicted_intent_index]
                    print(f"Predicted intent (label): {predicted_intent_label}")

                    base_responses = intent_responses.get(predicted_intent_label, ["I'm not sure I understand. Can you please rephrase?"])
                    response = random.choice(base_responses)
                else:
                    response = "I'm not sure I understand. Can you please rephrase?"

        except Exception as e:
            print(f"Error during prediction: {e}")
            response = "Sorry, something went wrong with the prediction."

        return JsonResponse({'message': response})
