import pickle

with open('chatbot/models/chatbot_model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('chatbot/models/tfidf_vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

# Function to get the chatbot's response
def get_response(user_input):
    user_input_vector = vectorizer.transform([user_input])
    predicted_intent = model.predict(user_input_vector)[0]

    responses = {
        1: "Hello! How can I assist you today?",
        2: "I'm doing well, thanks for asking!",
        3: "Let me help you with that.",
    }

    return responses.get(predicted_intent, "I'm sorry, I didn't understand that.")
