// Function to get the CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Function to send the message
function sendMessage() {
    var user_input = document.getElementById('user_input').value;

    if (user_input.trim() !== "") {
        var chatBox = document.getElementById('chat-box');
        chatBox.innerHTML += "<p><b>You:</b> " + user_input + "</p>";

        document.getElementById('user_input').value = '';

        var csrf_token = getCookie('csrftoken');

        fetch('/get-response/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-CSRFToken': csrf_token
            },
            body: new URLSearchParams({ 'message': user_input })
        })
        .then(response => response.json())
        .then(data => {
            chatBox.innerHTML += "<p><b>Bot:</b> " + data.message + "</p>";
        })
        .catch(error => {
            console.error('Error:', error);
            chatBox.innerHTML += "<p><b>Error:</b> There was an error processing your request.</p>";
        });
    }
}

document.getElementById('send-button').addEventListener('click', sendMessage);

document.getElementById('user_input').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        sendMessage();
    }
});
